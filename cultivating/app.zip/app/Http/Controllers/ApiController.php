<?php

namespace App\Http\Controllers;

// use Illuminate\Foundation\Auth\User as Authenticatable;
// use Tymon\JWTAuth\Contracts\JWTSubject;
// use Illuminate\Notifications\Notifiable;
use App\Http\Controllers\Controller;

use AppHttpRequestsRegisterAuthRequest;
use TymonJWTAuthExceptionsJWTException;
use JWTAuth,Session;
use Validator;
use IlluminateHttpRequest;
use AppHttpRequestsRegisterAuthRequest;
use TymonJWTAuthExceptionsJWTException;
use SymfonyComponentHttpFoundationResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Models\User;
use Mail, Hash, Auth;
// use App\Traits\ImagesTrait;


class ApiController extends Controller
{
    public function seller_registration(Request $request)
    {
        $input = $request->all();
        $validator = Validator::make(
            $request->all(),
            [
                'name'     => 'required',
                'password'      => 'required',
                'email'         => 'required|email'
            ]
        );

        if ($validator->fails()) {
            return response()->json(['error' => $validator->errors()], 200);
        }

        $check_email_exists = User::where('email', $input['email'])->first();
        
        if ($check_email_exists) {
            return response()->json(['status' => false,'message' => 'This Email is already exists', 'code' => 400]);
        }
        
        User::create([
                    'name'              => $input['name'],
                    'email'             => $input['email'],
                    'decrypt_password'  => $input['password'],
                    'password'          => Hash::make($input['password'])
                ]);

        return response()->json(['status' => true,'code'=>200,'message' => 'User registration successfully']);
    }

    public function user_login(Request $request)
    {
        $credentials = $request->only('email', 'password');
        print_r($credentials); die();
        $validator = Validator::make(
            $request->all(),
            [
                'email'      => 'required|email',
                'password'   => 'required'
            ]
        );
        if ($validator->fails()) {
            $response['code'] = 404;
            $response['status'] = $validator->errors()->first();
            $response['message'] = "missing parameters";
            return response()->json($response);
        }

        $token = JWTAuth::attempt($credentials);
        if ($token) {
            $user = auth()->userOrFail();
            return response()->json(['status' => true,'message' => 'User login Successfuly', 'token' => $token, 'data' => $user,'code' => 200]);
        } else {
            return response()->json(['status' => false,'message' => 'Something went wrong', 'code' => 400]);
        }
    }


}
